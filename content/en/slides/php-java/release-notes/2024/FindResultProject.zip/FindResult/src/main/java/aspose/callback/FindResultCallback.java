package aspose.callback;

import com.aspose.slides.IFindResultCallback;
import com.aspose.slides.ITextFrame;
import com.aspose.slides.Slide;

import java.util.ArrayList;
import java.util.List;

/**
 * Class that provides information about all found occurrences of a given text.
 */
public class FindResultCallback implements IFindResultCallback
{
    /**
     * Array of retrieved text information.
     */
    public final List<WordInfo> Words = new ArrayList<>();

    /**
     * The number of matches found to a given text.
     */
    public int getCount()
    {
        return Words.size();
    }

    /**
     * Gets all slides in which the given text was found.
     */
    public Integer[] getSlideNumbers()
    {
        List<Integer> slideNumbers = new ArrayList();
        for (WordInfo element : Words)
        {
            int slideNumber = ((Slide)element.TextFrame.getSlide()).getSlideNumber();
            if (!slideNumbers.contains(slideNumber))
                slideNumbers.add(slideNumber);
        }
        return slideNumbers.toArray(new Integer[0]);
    }

    /**
     * Gets all occurrences of the found text on the slide.
     * @param slideNumber Slide number
     */
    public WordInfo[] getElementsForSlide(int slideNumber)
    {
        List<WordInfo> foundElements = new ArrayList<>();
        for (WordInfo element : Words)
        {
            if (((Slide)element.TextFrame.getSlide()).getSlideNumber() == slideNumber)
                foundElements.add(element);
        }
        return foundElements.toArray(new WordInfo[0]);
    }

    /**
     * Callback method that receives data about the found text.
     * @param textFrame {@link ITextFrame} where searching text was found.
     * @param oldText The Old text
     * @param foundText The Found text.
     * @param textPosition Position of found text in source text.
     */
    public void foundResult(ITextFrame textFrame, String oldText, String foundText, int textPosition)
    {
        Words.add(new WordInfo(textFrame, oldText, foundText, textPosition));
    }
}
