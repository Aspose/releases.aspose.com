package aspose.callback;

import com.aspose.slides.ITextFrame;

/**
 * Class providing information about each text found in the presentation.
 */
public class WordInfo
{
    ITextFrame TextFrame;
    String SourceText;
    String FoundText;
    int TextPosition;

    WordInfo(ITextFrame textFrame, String sourceText, String foundText, int textPosition)
    {
        TextFrame = textFrame;
        SourceText = sourceText;
        FoundText = foundText;
        TextPosition = textPosition;
    }

    /**
     * Gets found text.
     */
    public String getFoundText() {
        return FoundText;
    }

    /**
     * Gets the source text for the TextFrame in which the text was found.
     */
    public String getSourceText() {
        return SourceText;
    }

    /**
     * The position of the found text in the text frame.
     */
    public int getTextPosition() {
        return TextPosition;
    }

    /**
     * The text frame in which the text was found.
     */
    public ITextFrame getTextFrame() {
        return TextFrame;
    }
}
