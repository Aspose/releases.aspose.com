package com.aspose.slides.phphelper;

import com.aspose.slides.BaseSlide;
import com.aspose.slides.ForEach_;
import com.aspose.slides.Paragraph;
import com.aspose.slides.Portion;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ForEachPortionCallbackImplementation implements ForEach_.ForEachPortionCallback {

    @Override
    public void invoke(Portion portion, Paragraph para, BaseSlide slide, int index) {
        String output = portion.getText() + ", index: " + index;

        try(FileWriter fw = new FileWriter("output.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw))
        {
            out.println(output);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
