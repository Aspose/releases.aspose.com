package com.aspose.slides.phphelper;

import com.aspose.slides.FrameTickEventArgs;
import com.aspose.slides.PresentationPlayer;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class FrameTickInterfaceImplementation implements PresentationPlayer.FrameTick {
    @Override
    public void invoke(PresentationPlayer sender, FrameTickEventArgs args) {
        try {
            ImageIO.write(args.getFrame(), "PNG", new File("frame_" + sender.getFrameIndex() + ".png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
